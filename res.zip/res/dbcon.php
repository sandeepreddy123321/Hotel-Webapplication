<?php
  $sql=mysqli_connect('localhost','root','','hotel');

  if($sql==true)
  {
     
  }
  

?>