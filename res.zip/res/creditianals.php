<?php
include('dbcon.php');
define("API_KEY",'Nzc1OTRiNjI2NjMzMzY0OTQzNTYzOTZmNTYzMjQ4NTA=');
define("MOBILE",'7821893289')

?>